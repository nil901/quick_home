import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

Color kblack = Color(0xFF000000);
Color kwhite = Color(0xFFFFFFFF);
HexColor kgrey = HexColor('#959595');


