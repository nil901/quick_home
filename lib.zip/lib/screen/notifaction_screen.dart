import 'package:flutter/material.dart';
import 'package:quick_home/color/colors.dart';

class NotificationScreen extends StatefulWidget {
  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  bool showUnread = false;

  final List<Map<String, dynamic>> notifications = [
    {
      "title": "Your booking has been confirmed.",
      "subtitle":
          "Your Service is successfully booked. Our professional will reach you on time.",
      "buttonText": "Track",
      "isUnread": true,
    },
    {
      "title": "Your service has started.",
      "subtitle": "The service is now in progress at your location.",
      "buttonText": "View",
      "isUnread": true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredNotifications =
        showUnread
            ? notifications.where((n) => n['isUnread'] == true).toList()
            : notifications;

    return Scaffold(
      backgroundColor: kwhite,
      appBar: AppBar(
        backgroundColor: kwhite,
        titleSpacing: 0,
        title: Text("Notifications", style: TextStyle(fontSize: 18)),
        actions: [
          IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    setState(() {
                      showUnread = false;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                    decoration: BoxDecoration(
                      color: showUnread ? Colors.transparent : Colors.grey[300],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      "All",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: showUnread ? Colors.black54 : Colors.black,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      showUnread = true;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                    decoration: BoxDecoration(
                      color: showUnread ? Colors.grey[300] : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      "Unread",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: showUnread ? Colors.black : Colors.black54,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 16),

            Expanded(
              child: ListView.builder(
                itemCount: filteredNotifications.length,
                itemBuilder: (context, index) {
                  final item = filteredNotifications[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Green dot for unread
                          if (item['isUnread'] == true)
                            Container(
                              margin: EdgeInsets.only(right: 12, top: 8),
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                              ),
                            )
                          else
                            SizedBox(width: 24),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['title'],
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  item['subtitle'],
                                  style: TextStyle(color: Colors.black54),
                                ),
                                SizedBox(height: 8),
                                OutlinedButton(
                                  onPressed: () {
                                    // Button action here
                                  },
                                  child: Text(item['buttonText']),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
