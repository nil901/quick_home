import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:quick_home/color/colors.dart';
import 'package:quick_home/screen/dashboard/services_details_screen.dart';
import 'package:quick_home/util/size.dart';

class SubCategoriesscreenDetails extends StatefulWidget {
  const SubCategoriesscreenDetails({super.key});

  @override
  State<SubCategoriesscreenDetails> createState() =>
      _SubCategoriesscreenDetailsState();
}

class _SubCategoriesscreenDetailsState
    extends State<SubCategoriesscreenDetails> {
  List<int> counters = [1, 0, 0];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kwhite,
      appBar: AppBar(
        leading: InkWell(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back, color: Colors.black)),
        backgroundColor: Colors.white,
        titleSpacing: 0,
        elevation: 0,
        title: Text(
          "Home Cleaning",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CleaningCardList(),
        
            ComboSection(
              title: "Fresh & Comfy Combo",
              offerCode: "NEW15",
              service: "Sofa + Carpet cleaning",
              price: 1499,
              oldPrice: 1999,
              rating: 4,
              reviews: "25 k reviews",
            ),
             SizedBox(height: 20),
                ComboSection(
                  title: "Sparkle Combo",
                  offerCode: "NEW15",
                  service: "Basic home + Bathroom",
                  price: 1499,
                  oldPrice: 1999,
                  rating: 4,
                  reviews: "10 k reviews",
                ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black,
            padding: EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          onPressed: () {},
          child: Text(
            "View Cart",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,color: kwhite),
          ),
        ),
      ),
    );
  }
}

class CleaningCardList extends StatefulWidget {
  const CleaningCardList({super.key});

  @override
  State<CleaningCardList> createState() => _CleaningCardListState();
}

class _CleaningCardListState extends State<CleaningCardList> {
  // Sample data
  List<Map<String, dynamic>> cleaningItems = [
    {
      "title": "Sparkling Home Cleaning",
      "description":
          "Deep clean for a spotless home dustfree, fresh, and shining.",
      "price": 399,
      "image":
          "https://img.freepik.com/free-photo/cleaning-service-person-home_23-2149001785.jpg",
      "reviews": "50k reviews",
    },
    {
      "title": "Bathroom Cleaning",
      "description": "Complete bathroom scrub and sanitization.",
      "price": 199,
      "image":
          "https://img.freepik.com/free-photo/cleaning-service-person-home_23-2149001785.jpg",
      "reviews": "10k reviews",
    },
    // Add more items here
  ];

  // Track booked status and count for each item
  List<bool> bookedStatus = [];
  List<int> countStatus = [];

  @override
  void initState() {
    super.initState();
    bookedStatus = List.generate(cleaningItems.length, (index) => false);
    countStatus = List.generate(cleaningItems.length, (index) => 0);
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: cleaningItems.length,
      padding: const EdgeInsets.all(12),
      itemBuilder: (context, index) {
        var item = cleaningItems[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white,
            border: Border.all(color: Colors.grey, width: 0.5),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image + Book Now / Counter
                Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        item["image"],
                        height: 80,
                        width: 80,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(height: 8),
                    bookedStatus[index]
                        ? Container(
                          height: 30,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    if (countStatus[index] > 0)
                                      countStatus[index]--;
                                    if (countStatus[index] == 0)
                                      bookedStatus[index] = false;
                                  });
                                },
                                child: const Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 1,
                                  ),
                                  child: Text(
                                    "–",
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.green,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                "${countStatus[index]}",
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                ),
                              ),
                              const SizedBox(width: 8),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    countStatus[index]++;
                                  });
                                },
                                child: const Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 1,
                                  ),
                                  child: Text(
                                    "+",
                                    style: TextStyle(
                                      fontSize: 19,
                                      color: Colors.green,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                        : InkWell(
                          onTap: () {
                            setState(() {
                              bookedStatus[index] = true;
                              countStatus[index] = 1;
                            });
                          },
                          child: Container(
                            // height: 35,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              border: Border.all(color: kgrey),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 5,
                                horizontal: 13,
                              ),
                              child: Text(
                                "Book Now",
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 15,
                                ),
                              ),
                            ),
                          ),
                        ),
                    const SizedBox(height: 8),
                    const Text(
                      "4 options",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 12),

                // Text Section
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item["title"],
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item["description"],
                        style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "Starts at ₹${item["price"]}",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: kblack,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(
                            Icons.star,
                            size: 16,
                            color: Colors.orangeAccent,
                          ),
                          const Icon(
                            Icons.star,
                            size: 16,
                            color: Colors.orangeAccent,
                          ),
                          const Icon(
                            Icons.star,
                            size: 16,
                            color: Colors.orangeAccent,
                          ),
                          const Icon(
                            Icons.star,
                            size: 16,
                            color: Colors.orangeAccent,
                          ),
                          const Icon(
                            Icons.star_half,
                            size: 16,
                            color: Colors.orangeAccent,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            "(${item["reviews"]})",
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:  [
                          InkWell(
                            onTap: (){
                                 Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ServicesDetailsScreen(),
                        ),
                      );
                              
                            },
                            child: Text(
                              "View Details",
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Combo Offers',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Scaffold(
        appBar: AppBar(title: Text('Combo Offers')),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              ComboSection(
                title: "Sparkle Combo",
                offerCode: "NEW15",
                service: "Basic home + Bathroom",
                price: 1499,
                oldPrice: 1999,
                rating: 4,
                reviews: "10 k reviews",
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ComboSection extends StatelessWidget {
  final String title;
  final String offerCode;
  final String service;
  final int price;
  final int oldPrice;
  final int rating;
  final String reviews;

  ComboSection({
    required this.title,
    required this.offerCode,
    required this.service,
    required this.price,
    required this.oldPrice,
    required this.rating,
    required this.reviews,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Material(
            elevation: 2,
            borderRadius: BorderRadius.circular(15),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: kwhite,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(12),
                        topLeft: Radius.circular(12),
                      ),
                      color: HexColor("#E9E9E9"),
                    ),
            
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text("Extra 15% off for new users with NEW15"),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          service,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              "AED $price",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(width: 8),
                            Text(
                              "AED $oldPrice",
                              style: TextStyle(
                                decoration: TextDecoration.lineThrough,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 6),
                        Row(
                          children: [
                            Row(
                              children: List.generate(5, (index) {
                                return Icon(
                                  index < rating ? Icons.star : Icons.star_border,
                                  size: 16,
                                  color: Colors.amber,
                                );
                              }),
                            ),
                            SizedBox(width: 5),
                            Text(
                              "($reviews)",
                              style: TextStyle(color: Colors.grey[700]),
                            ),
                          ],
                        ),
                        SizedBox(height: 12),
                        Row(
                          children: [
                           Text("View Details",style: TextStyle(fontSize: 13,color: HexColor("#00B342")),),
                            SizedBox(width: 10),
                           Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                             border: Border.all(width: 0.5,color: kgrey),
                             borderRadius: BorderRadius.circular(20)
                            ),
                            //height: 35,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4,horizontal: 10),
                              child: Text("Book Now",style: TextStyle(fontSize: 13,color: HexColor("#00B342")),),
                            ),
                           )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
