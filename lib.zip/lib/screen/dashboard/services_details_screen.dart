import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:quick_home/screen/dashboard/subscription_screen.dart';
import 'package:quick_home/screen/wigets/faq_comman.dart';
import 'package:quick_home/util/size.dart';
class ServicesDetailsScreen extends StatefulWidget {
  const ServicesDetailsScreen({super.key, });

 

  @override
  State<ServicesDetailsScreen> createState() => _ServicesDetailsScreenState();
}

class _ServicesDetailsScreenState extends State<ServicesDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.only(
                  top: 50,
                  left: 16,
                  right: 16,
                  bottom: 16,
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                    Text(
                      'Sparkling Home Cleaning',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    Container(width: 48), // Spacer for balance
                  ],
                ),
              ),
          
              // Main Image
              Center(
                child: Container(
                  height: 200,
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.grey[300],
                  ),
                  child: const Icon(
                    Icons.cleaning_services,
                    size: 80,
                    color: Colors.grey,
                  ),
                ),
              ),
          
              // Content
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title and Rating
                    const Row(
                      children: [
                        Text(
                          'Sparkling Home Cleaning',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
          
                    const SizedBox(height: 8),
          
                    // Description
                    const Text(
                      'Deep clean for a spotless home dust-free,\nfresh, and shining',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                        height: 1.5,
                      ),
                    ),
          
                    const SizedBox(height: 12),
          
                    // Rating
                    Row(
                      children: [
                        RatingBarIndicator(
                          rating: 4,
                          itemBuilder:
                              (context, index) =>
                                  const Icon(Icons.star, color: Colors.grey),
                          itemCount: 5,
                          itemSize: 16.0,
                          unratedColor: Colors.grey.shade300,
                          direction: Axis.horizontal,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          "(50k reviews)",
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
          
                    const SizedBox(height: 16),
          
                    // Pricing and Book Now
                    Row(
                      children: [
                        Text(
                          'AED 4999',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 10),
                        Text(
                          'AED 5499',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            decoration: TextDecoration.lineThrough,
                          ),
                        ),
                        const Spacer(),
          
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.green),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(
                              left: 12,
                              right: 12,
                              top: 1.9,
                              bottom: 1.9,
                            ),
                            child: Text(
                              'Book Now',
                              style: TextStyle(color: Colors.green, fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
          
                    const SizedBox(height: 24),
                    const Divider(),
                    // About the service
                    const Text(
                      '• About the service',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
          
                    const SizedBox(height: 8),
          
                    const Text(
                      'Bring back the shine to your home with our all-round cleaning service. From spotless floors and dust-free kitchens to fresh bathrooms, our experts ensure every corner gleams with hygiene.',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                        height: 1.5,
                      ),
                    ),
          
                    const SizedBox(height: 24),
                    const Divider(),
                    // What's included
                    Text(
                      '• What\'s Included',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
          
                    const SizedBox(height: 16),
          
                    // Services list
                    Text(
                      'Floor Cleaning: Sweeping, mopping, and stain removal of all rooms.',
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Dusting: Furniture, shelves, windowsills, fans, and décor items.',
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Bathroom Cleaning: Sink, tiles, taps, and mirror wipe-down.',
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Kitchen Cleaning: Countertop, stovetop, and outer surface cleaning of appliances.',
                    ),
                    SizedBox(height: 10),
                    Text('Trash Disposal: Garbage collection and disposal.'),
                    SizedBox(height: 10),
                    Text(
                      'Basic Sanitization: High-touch areas like door handles, switches, and railings.',
                    ),
          
                    const SizedBox(height: 24),
                    const Divider(),
          
                    // Details
                    const SizedBox(height: 16),
          
                    _buildDetailItem(
                      'Duration:',
                      '2-4 hours (depends on home size)',
                    ),
                    _buildDetailItem('Team:', '2+ professional cleaners'),
                    _buildDetailItem(
                      'Product Used:',
                      'Safe, eco-friendly cleaning supplies',
                    ),
          
                    const SizedBox(height: 24),
                    const Divider(),
                    // Subscription
                    const Text(
                      'Subscription',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
          
                    const SizedBox(height: 16),
          
                    // Subscription options
                    Row(
                      children: [
                        Expanded(
                          child: _buildSubscriptionOption(
                            'One-Time Quick Fix',
                            'Single service anytime you need',
                            'AED 2,599',
                            '3hr+',
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildSubscriptionOption(
                            'QuickCare Weekly',
                            'Short term plan with weekly savings',
                            'AED 1,999',
                            '3hr+',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Text("Frequently asked questions",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  h10,
              FaqComman()
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailItem(String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('•', style: TextStyle(fontSize: 16, color: Colors.black)),
          SizedBox(
            width: 80,
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 14, color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubscriptionOption(
    String title,
    String subtitle,
    String price,
    String duration,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 4),
          Text(
            price,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.orange[100],
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              duration,
              style: const TextStyle(
                fontSize: 12,
                color: Colors.orange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}