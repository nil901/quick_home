import 'package:flutter/material.dart';
import 'package:quick_home/color/colors.dart';
import 'package:quick_home/screen/dashboard/mid_screens/categories_screen_details.dart';
import 'package:quick_home/screen/dashboard/search_screen.dart';
import 'package:quick_home/screen/wigets/categorey_items.dart';
import 'package:quick_home/util/comman_app_bar.dart';
import 'package:quick_home/util/size.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kwhite,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: kwhite,
          appBar: const PreferredSize(
            preferredSize: Size.fromHeight(70),
            child: CommanAppBar(),
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// 🔍 Search bar
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SearchScreen()),
                      );
                    },
                    child: Container(
                      height: 45,
                      decoration: BoxDecoration(
                        color: kwhite,
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: kgrey, width: 0.5),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Row(
                          children: [
                            Image.asset(
                              "assets/images/search.png",
                              color: Colors.black,
                              height: 20,
                            ),
                            w10,
                            const Text(
                              "Search here...!",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                /// 📸 Banner (slider placeholder)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),

                h20,

                /// 🏷 Categories
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    "All Categories",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                h10,
                SizedBox(
                  height: 100,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      CategoryItem(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CategoriesScreenDetails(),
                            ),
                          );
                        },
                        title: "Cleaning",
                        icon: Icons.cleaning_services,
                      ),
                      CategoryItem(title: "Repair", icon: Icons.build),
                      CategoryItem(title: "Beauty", icon: Icons.face),
                      CategoryItem(
                        title: "Home",
                        icon: Icons.home_repair_service,
                      ),
                    ],
                  ),
                ),

                /// Sections
                _buildSection("Qwik Picks"),
                _buildSection("Popular Services"),
                _buildSection("Special Offers & Campaigns", single: true),
                _buildSection("Beauty, Qwik & Easy"),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 📦 Section Builder
  Widget _buildSection(String title, {bool single = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Heading + See All
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Text("See all", style: TextStyle(color: Colors.blue)),
            ],
          ),
        ),

        // Horizontal List
        SizedBox(
          height: single ? 150 : 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 4,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.only(left: 12),
                width: single ? 250 : 120,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(12),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
